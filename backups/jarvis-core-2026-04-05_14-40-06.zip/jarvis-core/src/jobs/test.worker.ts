import { Worker } from 'bullmq';
import { getRedisConnection } from './queue.provider.js';

const connection = getRedisConnection();

if (!connection) {
  throw new Error('REDIS_URL puudub. Worker ei saa käivituda.');
}

export const testWorker = new Worker(
  'jarvis-default',
  async (job) => {
    if (job.name === 'test-job') {
      return {
        ok: true,
        receivedAt: new Date().toISOString(),
        payload: job.data,
      };
    }

    return { ok: false, unknownJob: job.name };
  },
  {
    connection,
    prefix: 'jarvis',
  },
);
