import { Router, type Express } from 'express';

import { JobsService } from './jobs.service.js';
import './test.worker.js';

const jobsService = new JobsService();

export const registerJobsModule = (app: Express) => {
  const router = Router();

  router.get('/status', (_request, response) => {
    response.json({
      status: 'ready',
      jobs: jobsService.list(),
    });
  });

  router.post('/test', async (_request, response) => {
    const result = await jobsService.enqueueTestJob();

    response.json({
      status: 'ready',
      job: result,
    });
  });

  app.use('/api/jobs', router);
};
