#!/bin/sh
set -eu

ID="${1:-}"

if [ -z "$ID" ]; then
  echo "SAFE_RUN_ID_REQUIRED"
  exit 2
fi

case "$ID" in
  pwd)
    CMD='pwd'
    ;;
  health)
    CMD='curl -s http://localhost:3000/health'
    ;;
  pm2_status_jarvis)
    CMD='pm2 status jarvis'
    ;;
  status_summary)
    CMD='curl -s -X POST http://localhost:3000/api/voice/turns -H "Content-Type: application/json" -d '\''{"text":"kontrolli jarvise seisu","locale":"et-EE","inputMode":"text","outputMode":"text"}'\'''
    ;;
  debug_logs_text)
    CMD='curl -s http://localhost:3000/api/debug/logs/text'
    ;;
  terminal_last_json)
    CMD='curl -s http://localhost:3000/api/debug/terminal-last/json'
    ;;
  *)
    echo "SAFE_RUN_NOT_ALLOWED: $ID"
    exit 3
    ;;
esac

./scripts/terminal-capture.sh "$CMD"
