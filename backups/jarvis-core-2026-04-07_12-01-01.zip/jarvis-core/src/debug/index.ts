import fs from 'node:fs/promises';
import path from 'node:path';
import { Router, type Express } from 'express';

const router = Router();

async function readLastLines(filePath: string, maxLines = 60) {
  try {
    const content = await fs.readFile(filePath, 'utf8');
    const lines = content.split('\n');
    return lines.slice(-maxLines).join('\n');
  } catch {
    return '';
  }
}

router.get('/logs', async (_req, res) => {
  const cwd = process.cwd();

  const backendPath = path.join(cwd, 'logs', 'jarvis-backend.log');
  const watcherPath = path.join(cwd, 'logs', 'jarvis-watcher.log');

  const backend = await readLastLines(backendPath, 120);
  const watcher = await readLastLines(watcherPath, 200);

  res.json({
    ok: true,
    backendPath,
    watcherPath,
    backend,
    watcher,
  });
});

router.get('/logs/text', async (_req, res) => {
  const cwd = process.cwd();

  const backendPath = path.join(cwd, 'logs', 'jarvis-backend.log');
  const watcherPath = path.join(cwd, 'logs', 'jarvis-watcher.log');

  const backend = await readLastLines(backendPath, 80);
  const watcher = await readLastLines(watcherPath, 120);

  res.type('text/plain; charset=utf-8').send(
`===== BACKEND LOGI =====
${backend || '(tühi)'}

===== WATCHER LOGI =====
${watcher || '(tühi)'}
`
  );
});

router.get('/terminal-last', async (_req, res) => {
  const cwd = process.cwd();
  const terminalPath = path.join(cwd, 'logs', 'terminal-last.txt');

  try {
    const content = await fs.readFile(terminalPath, 'utf8');
    res.type('text/plain; charset=utf-8').send(content || '(tühi)');
  } catch {
    res.type('text/plain; charset=utf-8').send('(terminal capture puudub)');
  }
});

router.get('/terminal-last/json', async (_req, res) => {
  const cwd = process.cwd();
  const terminalJsonPath = path.join(cwd, 'logs', 'terminal-last.json');

  try {
    const content = await fs.readFile(terminalJsonPath, 'utf8');
    res.type('application/json; charset=utf-8').send(content || '{}');
  } catch {
    res.json({
      ok: false,
      message: 'terminal capture puudub',
    });
  }
});

router.get('/terminal-allowed', (_req, res) => {
  res.json({
    ok: true,
    allowed: [
      'pwd',
      'health',
      'pm2_status_jarvis',
      'status_summary',
      'debug_logs_text',
      'terminal_last_json',
    ],
  });
});

router.post('/terminal-run/:id', async (req, res) => {
  const cwd = process.cwd();
  const { execFile } = await import('node:child_process');

  const id = String(req.params.id ?? '').trim();

  execFile(
    path.join(cwd, 'scripts', 'terminal-safe-run.sh'),
    [id],
    { cwd, timeout: 20000 },
    async (error, stdout, stderr) => {
      const terminalJsonPath = path.join(cwd, 'logs', 'terminal-last.json');

      let lastCapture = null;

      try {
        const content = await fs.readFile(terminalJsonPath, 'utf8');
        lastCapture = JSON.parse(content);
      } catch {
        lastCapture = null;
      }

      if (error) {
        res.status(400).json({
          ok: false,
          id,
          error: error.message,
          stdout,
          stderr,
          lastCapture,
        });
        return;
      }

      res.json({
        ok: true,
        id,
        stdout,
        stderr,
        lastCapture,
      });
    },
  );
});

export const registerDebugRoutes = (app: Express) => {
  app.get('/debug/sentry-test', (_request, _response) => {
    throw new Error('Sentry test error from Jarvis');
  });
  app.use('/api/debug', router);
};
