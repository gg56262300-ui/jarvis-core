# Jarvis Backlog

## NOW

## NEXT
- Gmail voice action flow

## LATER

## DONE
- Agent control layer
- Calendar voice output pehmendamine
