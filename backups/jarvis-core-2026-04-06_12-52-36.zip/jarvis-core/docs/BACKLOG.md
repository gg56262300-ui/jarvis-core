# Jarvis Backlog

## NOW

## NEXT

## LATER

## NEXT
- Calendar voice output pehmendamine
