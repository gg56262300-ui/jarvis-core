import type { VoiceTurnResult } from './voice.types.js';

type FormattedVoiceOutput = {
  displayText: string;
  speechText: string;
};

const UNITS = [
  'null',
  'üks',
  'kaks',
  'kolm',
  'neli',
  'viis',
  'kuus',
  'seitse',
  'kaheksa',
  'üheksa',
];

const TEENS: Record<number, string> = {
  10: 'kümme',
  11: 'üksteist',
  12: 'kaksteist',
  13: 'kolmteist',
  14: 'neliteist',
  15: 'viisteist',
  16: 'kuusteist',
  17: 'seitseteist',
  18: 'kaheksateist',
  19: 'üheksateist',
};

const TENS: Record<number, string> = {
  2: 'kakskümmend',
  3: 'kolmkümmend',
  4: 'nelikümmend',
  5: 'viiskümmend',
  6: 'kuuskümmend',
  7: 'seitsekümmend',
  8: 'kaheksakümmend',
  9: 'üheksakümmend',
};

export const formatVoiceOutputTexts = (text: string): FormattedVoiceOutput => {
  const displayText = normalizeDisplayText(text);
  const speechText = normalizeSpeechText(displayText);

  return {
    displayText,
    speechText,
  };
};

export const applyVoiceOutputFormatting = (
  result: VoiceTurnResult,
): VoiceTurnResult => {
  const formatted = formatVoiceOutputTexts(result.responseText);

  return {
    ...result,
    responseText: formatted.displayText,
    displayText: formatted.displayText,
    speechText: formatted.speechText,
  };
};

const normalizeDisplayText = (text: string) => {
  return text
    .replace(/\s+/g, ' ')
    .replace(/\s([.,!?;:])/g, '$1')
    .trim();
};

const normalizeSpeechText = (text: string) => {
  let speech = text;

  speech = speech.replace(/\b(\d{1,2}):(\d{2})(?::(\d{2}))?\b/g, (_m, h, m, s) => {
    const parts = [numberToEstonianWords(Number(h)), numberToEstonianWords(Number(m))];
    if (s !== undefined) parts.push(numberToEstonianWords(Number(s)));
    return parts.join(' … ');
  });

  speech = speech.replace(/\b(\d{1,2})\.\s*([A-Za-zÀ-ÿÕÄÖÜõäöü]+)\s+(\d{4})\b/g, (_m, d, month, y) => {
    return `${numberToEstonianWords(Number(d))} ${month} ${numberToEstonianWords(Number(y))}`;
  });

  speech = speech.replace(/\b\d+\b/g, (match) => {
    const number = Number(match);
    if (!Number.isSafeInteger(number) || number < 0 || number > 999999) {
      return match;
    }
    return numberToEstonianWords(number);
  });

  return speech
    .replace(/\s*\((\d[\d\s.,/]*)\)/g, '')
    .replace(/:/g, ' … ')
    .replace(/;/g, ' … ')
    .replace(/,/g, ' … ')
    .replace(/\./g, '. … ')
    .replace(/\?/g, '? … ')
    .replace(/!/g, '! … ')
    .replace(/…\s*…/g, '…')
    .replace(/\s+/g, ' ')
    .trim();
};

const numberToEstonianWords = (value: number): string => {
  if (value < 10) return UNITS[value];
  if (value < 20) return TEENS[value];

  if (value < 100) {
    const tens = Math.floor(value / 10);
    const unit = value % 10;
    return unit === 0 ? TENS[tens] : `${TENS[tens]} ${UNITS[unit]}`;
  }

  if (value < 1000) {
    const hundreds = Math.floor(value / 100);
    const rest = value % 100;
    const hundredWord = hundreds === 1 ? 'sada' : `${UNITS[hundreds]}sada`;
    return rest === 0 ? hundredWord : `${hundredWord} ${numberToEstonianWords(rest)}`;
  }

  if (value < 1000000) {
    const thousands = Math.floor(value / 1000);
    const rest = value % 1000;
    const thousandWord = thousands === 1 ? 'tuhat' : `${numberToEstonianWords(thousands)} tuhat`;
    return rest === 0 ? thousandWord : `${thousandWord} ${numberToEstonianWords(rest)}`;
  }

  return String(value);
};
