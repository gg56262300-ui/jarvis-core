#!/bin/sh
set -u

mkdir -p logs
OUT_TXT="logs/terminal-last.txt"
OUT_JSON="logs/terminal-last.json"
OUT_HISTORY="logs/terminal-history.ndjson"

CMD="${*:-}"
TS="$(date '+%Y-%m-%d %H:%M:%S')"
PWD_NOW="$(pwd)"
TMP_OUT="$(mktemp)"
TMP_CLEAN="$(mktemp)"

if [ "$#" -gt 0 ]; then
  sh -c "$*" >"$TMP_OUT" 2>&1
  CODE=$?
else
  echo "(no command provided)" >"$TMP_OUT"
  CODE=0
fi

python3 - <<PY
import pathlib, re
raw = pathlib.Path("$TMP_OUT").read_text()
clean = re.sub(r'\x1B\[[0-?]*[ -/]*[@-~]', '', raw)
pathlib.Path("$TMP_CLEAN").write_text(clean)
PY

{
  echo "===== TERMINAL CAPTURE ====="
  echo "time: $TS"
  echo "pwd: $PWD_NOW"
  echo "cmd: $CMD"
  echo "----- OUTPUT START -----"
  cat "$TMP_CLEAN"
  echo "----- OUTPUT END -----"
  echo "exit_code: $CODE"
} > "$OUT_TXT"

export JARVIS_CAPTURE_TIME="$TS"
export JARVIS_CAPTURE_PWD="$PWD_NOW"
export JARVIS_CAPTURE_CMD="$CMD"
export JARVIS_CAPTURE_CODE="$CODE"
export JARVIS_CAPTURE_CLEAN="$TMP_CLEAN"
export JARVIS_CAPTURE_JSON="$OUT_JSON"
export JARVIS_CAPTURE_HISTORY="$OUT_HISTORY"

python3 - <<'PY'
import json, os, pathlib
out = pathlib.Path(os.environ["JARVIS_CAPTURE_CLEAN"]).read_text()
data = {
  "time": os.environ["JARVIS_CAPTURE_TIME"],
  "pwd": os.environ["JARVIS_CAPTURE_PWD"],
  "cmd": os.environ["JARVIS_CAPTURE_CMD"],
  "exit_code": int(os.environ["JARVIS_CAPTURE_CODE"]),
  "output": out,
}
pathlib.Path(os.environ["JARVIS_CAPTURE_JSON"]).write_text(
  json.dumps(data, ensure_ascii=False, indent=2)
)
with pathlib.Path(os.environ["JARVIS_CAPTURE_HISTORY"]).open("a", encoding="utf-8") as f:
  f.write(json.dumps(data, ensure_ascii=False) + "\n")
PY

rm -f "$TMP_OUT" "$TMP_CLEAN"
cat "$OUT_TXT"
exit "$CODE"
