const statusText = document.getElementById('status-text');
const statusDot = document.getElementById('status-dot');
const transcript = document.getElementById('transcript');
const response = document.getElementById('response');
const talkButton = document.getElementById('talk-button');
const stopButton = document.getElementById('stop-button');
const sendTextButton = document.getElementById('send-text-button');
const textInput = document.getElementById('text-input');
const inputModeLabel = document.getElementById('input-mode-label');
const installButton = document.getElementById('install-button');

let deferredInstallPrompt = null;
let recognition = null;
let isListening = false;

const statusLabels = {
  idle: 'Ootel',
  listening: 'Kuulan',
  processing: 'Töötlen',
  speaking: 'Vastan',
};

const setStatus = (status) => {
  statusText.textContent = statusLabels[status] ?? 'Ootel';
  statusDot.className = `status-dot ${status === 'idle' ? '' : status}`.trim();
};

const setTranscript = (text) => {
  transcript.textContent = text || 'Sinu jutt ilmub siia.';
  transcript.classList.toggle('muted', !text);
};

const setResponse = (text) => {
  response.textContent = text || 'Jarvis on valmis.';
};

const speakResponse = (text) => {
  if (!('speechSynthesis' in window) || !text) {
    setStatus('idle');
    return;
  }

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'et-EE';
  utterance.onend = () => setStatus('idle');
  utterance.onerror = () => setStatus('idle');
  window.speechSynthesis.speak(utterance);
};

const sendTurn = async (text, source) => {
  setTranscript(text);
  inputModeLabel.textContent = source === 'speech' ? 'hääl' : 'tekst';
  setStatus('processing');

  try {
    const request = await fetch('/api/voice/turns', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        text,
        locale: 'et-EE',
        inputMode: source === 'speech' ? 'speech' : 'text',
        outputMode: 'text',
      }),
    });

    if (!request.ok) {
      let errorText = '';
      try {
        errorText = await request.text();
      } catch {
        errorText = '';
      }
      setResponse(`Jarvise vastuse loomine ebaõnnestus. ${errorText}`.trim());
      setStatus('idle');
      return;
    }

    const result = await request.json();
    const answer =
      result?.displayText ||
      result?.responseText ||
      result?.speechText ||
      'Jarvis ei tagastanud vastust.';

    setResponse(answer);
    setStatus('speaking');
    speakResponse(answer);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    setResponse(`Viga ühenduses: ${message}`);
    setStatus('idle');
  }
};

const createSpeechRecognition = () => {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    return null;
  }

  const nextRecognition = new SpeechRecognition();
  nextRecognition.lang = 'et-EE';
  nextRecognition.interimResults = true;
  nextRecognition.continuous = false;

  nextRecognition.onstart = () => {
    isListening = true;
    setStatus('listening');
  };

  nextRecognition.onresult = (event) => {
    const finalText = Array.from(event.results)
      .map((result) => result[0]?.transcript ?? '')
      .join(' ')
      .trim();

    setTranscript(finalText);
  };

  nextRecognition.onerror = () => {
    isListening = false;
    setStatus('idle');
    setResponse('Brauseri kõnetuvastus ei õnnestunud. Kasuta all olevat tekstivälja.');
  };

  nextRecognition.onend = async () => {
    if (!isListening) {
      setStatus('idle');
      return;
    }

    isListening = false;
    const text = transcript.textContent === 'Sinu jutt ilmub siia.' ? '' : transcript.textContent.trim();

    if (!text) {
      setStatus('idle');
      return;
    }

    await sendTurn(text, 'speech');
  };

  return nextRecognition;
};

const startListening = () => {
  if (!recognition) {
    recognition = createSpeechRecognition();
  }

  if (!recognition) {
    setResponse('Selles brauseris puudub kõnetuvastus. Kasuta tekstivälja.');
    return;
  }

  setTranscript('');
  recognition.start();
};

const stopListening = () => {
  isListening = false;

  if (recognition) {
    recognition.stop();
  }

  window.speechSynthesis?.cancel();
  setStatus('idle');
};

talkButton.addEventListener('pointerdown', () => {
  if (isListening) {
    return;
  }

  isListening = true;
  startListening();
});

talkButton.addEventListener('pointerup', () => {
  if (recognition && isListening) {
    recognition.stop();
  }
});

talkButton.addEventListener('pointercancel', stopListening);
stopButton.addEventListener('click', stopListening);

sendTextButton.addEventListener('click', async () => {
  const text = textInput.value.trim();

  if (!text) {
    setResponse('Sisesta kõigepealt tekst, mida Jarvis peaks töötlema.');
    return;
  }

  await sendTurn(text, 'text');
});

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  deferredInstallPrompt = event;
  installButton.hidden = false;
});

installButton.addEventListener('click', async () => {
  if (!deferredInstallPrompt) {
    return;
  }

  deferredInstallPrompt.prompt();
  await deferredInstallPrompt.userChoice;
  deferredInstallPrompt = null;
  installButton.hidden = true;
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      await navigator.serviceWorker.register('/sw.js');
    } catch {
      // Keep the first version silent if the service worker is unavailable.
    }
  });
}

setStatus('idle');

