#!/bin/sh
set -eu

mkdir -p logs
OUT="logs/terminal-last.txt"

CMD="${*:-}"
TS="$(date '+%Y-%m-%d %H:%M:%S')"
PWD_NOW="$(pwd)"

{
  echo "===== TERMINAL CAPTURE ====="
  echo "time: $TS"
  echo "pwd: $PWD_NOW"
  echo "cmd: $CMD"
  echo "----- OUTPUT START -----"
  if [ "$#" -gt 0 ]; then
    sh -c "$*" 2>&1
    CODE=$?
  else
    echo "(no command provided)"
    CODE=0
  fi
  echo "----- OUTPUT END -----"
  echo "exit_code: $CODE"
} > "$OUT"

cat "$OUT"
