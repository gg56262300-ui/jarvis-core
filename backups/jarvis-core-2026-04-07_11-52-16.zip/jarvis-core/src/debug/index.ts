import fs from 'node:fs/promises';
import path from 'node:path';
import { Router, type Express } from 'express';

const router = Router();

async function readLastLines(filePath: string, maxLines = 60) {
  try {
    const content = await fs.readFile(filePath, 'utf8');
    const lines = content.split('\n');
    return lines.slice(-maxLines).join('\n');
  } catch {
    return '';
  }
}

router.get('/logs', async (_req, res) => {
  const cwd = process.cwd();

  const backendPath = path.join(cwd, 'logs', 'jarvis-backend.log');
  const watcherPath = path.join(cwd, 'logs', 'jarvis-watcher.log');

  const backend = await readLastLines(backendPath, 120);
  const watcher = await readLastLines(watcherPath, 200);

  res.json({
    ok: true,
    backendPath,
    watcherPath,
    backend,
    watcher,
  });
});

router.get('/logs/text', async (_req, res) => {
  const cwd = process.cwd();

  const backendPath = path.join(cwd, 'logs', 'jarvis-backend.log');
  const watcherPath = path.join(cwd, 'logs', 'jarvis-watcher.log');

  const backend = await readLastLines(backendPath, 80);
  const watcher = await readLastLines(watcherPath, 120);

  res.type('text/plain; charset=utf-8').send(
`===== BACKEND LOGI =====
${backend || '(tühi)'}

===== WATCHER LOGI =====
${watcher || '(tühi)'}
`
  );
});

router.get('/terminal-last', async (_req, res) => {
  const cwd = process.cwd();
  const terminalPath = path.join(cwd, 'logs', 'terminal-last.txt');

  try {
    const content = await fs.readFile(terminalPath, 'utf8');
    res.type('text/plain; charset=utf-8').send(content || '(tühi)');
  } catch {
    res.type('text/plain; charset=utf-8').send('(terminal capture puudub)');
  }
});

export const registerDebugRoutes = (app: Express) => {
  app.get('/debug/sentry-test', (_request, _response) => {
    throw new Error('Sentry test error from Jarvis');
  });
  app.use('/api/debug', router);
};
