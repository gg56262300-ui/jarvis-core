#!/bin/sh
set -eu

mkdir -p tmp
OUT="tmp/jarvis-ops-lite.txt"

HEALTH="$(curl -s http://localhost:3000/health || true)"
CONTROL="$(curl -s http://localhost:3000/api/debug/control-summary-compact || true)"
EXEC="$(curl -s http://localhost:3000/api/debug/execution-state-compact || true)"
PM2_JSON="$(pm2 jlist 2>/dev/null || true)"

export HEALTH CONTROL EXEC PM2_JSON OUT

python3 - <<'PY'
import json, os
from pathlib import Path

out_path = Path(os.environ["OUT"])

def load(raw: str):
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return raw

health = load(os.environ.get("HEALTH", ""))
control = load(os.environ.get("CONTROL", ""))
exec_state = load(os.environ.get("EXEC", ""))
pm2 = load(os.environ.get("PM2_JSON", ""))

health_status = "missing"
if isinstance(health, dict):
    health_status = str(health.get("status") or "missing")
elif isinstance(health, str) and health:
    health_status = health[:80]

pm2_status = "missing"
if isinstance(pm2, list):
    jarvis = next((x for x in pm2 if x.get("name") == "jarvis"), None)
    if jarvis:
        pm2_status = str((jarvis.get("pm2_env") or {}).get("status") or "missing")

control_summary = "missing"
if isinstance(control, dict):
    control_summary = json.dumps(control, ensure_ascii=False)
elif isinstance(control, str) and control:
    control_summary = " ".join(control.split())

execution_summary = "missing"
if isinstance(exec_state, dict):
    execution_summary = f"status={exec_state.get('currentStatus')}, step={exec_state.get('currentStepIndex')}/{exec_state.get('currentTotalSteps')}"
elif isinstance(exec_state, str) and exec_state:
    execution_summary = " ".join(exec_state.split())

text = (
    "===== JARVIS OPS LITE =====\n"
    f"health: {health_status}\n"
    f"pm2: {pm2_status}\n"
    f"control: {control_summary[:300]}\n"
    f"execution: {execution_summary[:300]}\n"
)

out_path.write_text(text, encoding="utf-8")
print(text, end="")
PY

pbcopy < "$OUT"
echo
echo "===== COPIED TO CLIPBOARD ====="
echo "$OUT"
