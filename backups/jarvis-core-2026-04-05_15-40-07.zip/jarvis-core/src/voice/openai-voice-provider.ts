import OpenAI from 'openai';

import { env } from '../config/env.js';
import { VOICE_SYSTEM_PROMPT } from './prompts/voice-system.prompt.js';
import type { VoiceTurnInput, VoiceTurnResult } from './voice.types.js';

export class OpenAiVoiceAssistantProvider {
  private readonly client: OpenAI;

  constructor() {
    if (!env.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY puudub .env failist');
    }

    this.client = new OpenAI({
      apiKey: env.OPENAI_API_KEY,
    });
  }

  async respond(input: VoiceTurnInput): Promise<VoiceTurnResult> {
    const completion = await this.client.chat.completions.create({
      model: 'gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: VOICE_SYSTEM_PROMPT,
        },
        {
          role: 'user',
          content: input.text,
        },
      ],
    });

    const responseText =
      completion.choices[0]?.message?.content?.trim() ||
      'Sain su sõnumi kätte, aga vastus jäi tühjaks.';

    return {
      transcript: input.text.trim(),
      responseText,
      locale: input.locale,
      inputMode: input.source,
      outputMode: 'text',
      status: 'speaking',
    };
  }
}