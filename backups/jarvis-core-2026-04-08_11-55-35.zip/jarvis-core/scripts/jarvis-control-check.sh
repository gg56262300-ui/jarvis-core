#!/bin/sh
set -eu

echo "===== CONTROL CHECK ====="
curl -s -X POST http://localhost:3000/api/debug/terminal-run/control_summary
echo
echo
echo "===== PM2 STATUS ====="
pm2 status jarvis
