#!/bin/sh
set -eu

LABEL="${1:-ops-master-flow}"

echo "===== FLOW START ====="
./scripts/jarvis-copy-run.sh "curl -s -X POST http://localhost:3000/api/debug/execution/start -H 'Content-Type: application/json' -d '{\"label\":\"$LABEL\",\"totalSteps\":4}'"

echo
echo "===== FLOW STEP 1: HEALTH ====="
./scripts/jarvis-copy-run.sh "curl -s http://localhost:3000/health"
./scripts/jarvis-copy-run.sh "curl -s -X POST http://localhost:3000/api/debug/execution/step -H 'Content-Type: application/json' -d '{\"stepIndex\":1,\"stepLabel\":\"health checked\",\"stepStatus\":\"completed\"}'"

echo
echo "===== FLOW STEP 2: PM2 ====="
./scripts/jarvis-copy-run.sh "pm2 status jarvis"
./scripts/jarvis-copy-run.sh "curl -s -X POST http://localhost:3000/api/debug/execution/step -H 'Content-Type: application/json' -d '{\"stepIndex\":2,\"stepLabel\":\"pm2 checked\",\"stepStatus\":\"completed\"}'"

echo
echo "===== FLOW STEP 3: CONTROL SUMMARY ====="
./scripts/jarvis-safe-copy-plain.sh control_summary_compact
./scripts/jarvis-copy-run.sh "curl -s -X POST http://localhost:3000/api/debug/execution/step -H 'Content-Type: application/json' -d '{\"stepIndex\":3,\"stepLabel\":\"control summary checked\",\"stepStatus\":\"completed\"}'"

echo
echo "===== FLOW STEP 4: EXECUTION COMPLETE ====="
./scripts/jarvis-copy-run.sh "curl -s -X POST http://localhost:3000/api/debug/execution/complete -H 'Content-Type: application/json' -d '{\"stepLabel\":\"ops master flow complete\"}'"

echo
echo "===== FLOW FINAL CHECK ====="
./scripts/jarvis-safe-copy-plain.sh execution_state_compact
