#!/bin/bash
set -euo pipefail

if [ $# -ne 1 ]; then
  echo "USAGE: ./scripts/validate-command.sh <file>"
  exit 2
fi

FILE="$1"

if [ ! -f "$FILE" ]; then
  echo "VALIDATION: FAIL"
  echo "REASON: file not found"
  exit 1
fi

echo "===== VALIDATOR INPUT ====="
cat "$FILE"
echo

BLOCK_PATTERNS=(
  'rm -rf /'
  'sudo rm'
  'mkfs'
  'dd if='
  ':(){ :|:& };:'
  'chmod -R 777 /'
)

for pattern in "${BLOCK_PATTERNS[@]}"; do
  if grep -Fqi "$pattern" "$FILE"; then
    echo "VALIDATION: BLOCKED"
    echo "REASON: blocked pattern -> $pattern"
    exit 1
  fi
done

case "$FILE" in
  *.sh|*.bash)
    if bash -n "$FILE"; then
      echo "BASH SYNTAX: PASS"
    else
      echo "VALIDATION: FAIL"
      echo "REASON: bash syntax error"
      exit 1
    fi

    if command -v shellcheck >/dev/null 2>&1; then
      if shellcheck "$FILE"; then
        echo "SHELLCHECK: PASS"
      else
        echo "VALIDATION: FAIL"
        echo "REASON: shellcheck found issues"
        exit 1
      fi
    else
      echo "SHELLCHECK: SKIPPED"
    fi
    ;;
  *.js|*.cjs|*.mjs)
    if node --check "$FILE"; then
      echo "NODE SYNTAX: PASS"
    else
      echo "VALIDATION: FAIL"
      echo "REASON: node syntax error"
      exit 1
    fi
    ;;
  *)
    echo "VALIDATION MODE: BASIC"
    ;;
esac

echo "VALIDATION: PASS"
