import { z } from 'zod';

export const googleCalendarAuthorizationSchema = z.object({
  code: z.string().trim().min(1, 'Google autoriseerimiskood on kohustuslik.'),
});
