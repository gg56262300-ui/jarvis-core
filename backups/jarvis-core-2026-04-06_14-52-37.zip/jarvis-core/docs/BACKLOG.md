# Jarvis Backlog

## NOW
- Gmail voice action flow

## NEXT
- Sentry basic
- WhatsApp Business lead-first flow

## LATER

## DONE
- Agent control layer
- Calendar voice output pehmendamine
