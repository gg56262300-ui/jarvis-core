#!/bin/sh
set -u

mkdir -p logs
OUT_TXT="logs/terminal-last.txt"
OUT_JSON="logs/terminal-last.json"

CMD="${*:-}"
TS="$(date '+%Y-%m-%d %H:%M:%S')"
PWD_NOW="$(pwd)"
TMP_OUT="$(mktemp)"

if [ "$#" -gt 0 ]; then
  sh -c "$*" >"$TMP_OUT" 2>&1
  CODE=$?
else
  echo "(no command provided)" >"$TMP_OUT"
  CODE=0
fi

{
  echo "===== TERMINAL CAPTURE ====="
  echo "time: $TS"
  echo "pwd: $PWD_NOW"
  echo "cmd: $CMD"
  echo "----- OUTPUT START -----"
  cat "$TMP_OUT"
  echo "----- OUTPUT END -----"
  echo "exit_code: $CODE"
} > "$OUT_TXT"

python3 - <<PY
import json, pathlib
out = pathlib.Path("$TMP_OUT").read_text()
data = {
  "time": "$TS",
  "pwd": "$PWD_NOW",
  "cmd": "$CMD",
  "exit_code": $CODE,
  "output": out
}
pathlib.Path("$OUT_JSON").write_text(json.dumps(data, ensure_ascii=False, indent=2))
PY

rm -f "$TMP_OUT"
cat "$OUT_TXT"
exit 0
