#!/bin/sh
set -eu

CHANGE="${1:-undefined change}"
RISK="${2:-unknown}"
BLOCK="${3:-unknown}"
PROOF="${4:-missing}"
BACKUP="${5:-no}"

echo "===== JARVIS PRECHECK ====="
echo "MUUDATUS: $CHANGE"
echo "RISK: $RISK"
echo "PLOKI SUURUS: $BLOCK"
echo "TÕESTUS: $PROOF"
echo "BACKUP: $BACKUP"

DECISION="proceed"

if [ "$RISK" = "unknown" ] || [ "$PROOF" = "missing" ]; then
  DECISION="stop"
fi

if [ "$RISK" = "high" ] && [ "$BLOCK" != "small" ]; then
  DECISION="stop"
fi

if [ "$BACKUP" = "no" ] && [ "$RISK" != "low" ]; then
  DECISION="stop"
fi

echo "OTSUS: $DECISION"

if [ "$DECISION" = "stop" ]; then
  exit 1
fi
