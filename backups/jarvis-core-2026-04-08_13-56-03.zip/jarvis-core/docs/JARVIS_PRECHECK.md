# JARVIS PRECHECK

## Enne igat muudatust kontrolli 4 asja

1. Mida see muudab?
2. Mida see võib lõhkuda?
3. Kuidas ma tõestan, et see ei lõhkunud?
4. Kas pärast seda on vaja checkpoint-backup?

## Vastuse vorm

- MUUDATUS:
- RISK:
- TÕESTUS:
- BACKUP: yes/no
- OTSUS: proceed / stop

## Reegel

Kui risk või mõju ei ole selge, siis otsus = STOP.
Kui test puudub, siis otsus = STOP.
Kui muutus puudutab state, rollback, execution või terminal capture loogikat, siis backup = YES.
