export class JobsService {
  list() {
    return [];
  }
}

