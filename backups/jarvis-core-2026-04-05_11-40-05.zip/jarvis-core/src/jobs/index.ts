import type { Express } from 'express';

import { createModuleRouter } from '../shared/http/create-module-router.js';

export const registerJobsModule = (app: Express) => {
  app.use('/api/jobs', createModuleRouter('jobs'));
};
