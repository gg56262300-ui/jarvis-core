import type { Express } from 'express';

import { createModuleRouter } from '../shared/http/create-module-router.js';

export const registerCrmModule = (app: Express) => {
  app.use('/api/crm', createModuleRouter('crm'));
};

