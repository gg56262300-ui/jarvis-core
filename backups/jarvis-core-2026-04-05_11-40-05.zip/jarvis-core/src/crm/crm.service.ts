export class CrmService {
  listAccounts() {
    return [];
  }
}

