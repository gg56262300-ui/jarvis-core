import express from 'express';
import path from 'node:path';

import { registerAiRoutingModule } from './ai-routing/index.js';
import { registerCalendarModule } from './calendar/index.js';
import { registerContactsModule } from './contacts/index.js';
import { registerCrmModule } from './crm/index.js';
import { registerGmailModule } from './gmail/index.js';
import { registerJobsModule } from './jobs/index.js';
import { registerRemindersModule } from './reminders/index.js';
import { registerTranslationModule } from './translation/index.js';
import { registerVoiceModule } from './voice/index.js';
import { registerDebugRoutes } from './debug/index.js';
import { httpLogger } from './shared/logger/http-logger.js';
import { databaseProvider } from './shared/database/index.js';
import { errorHandler } from './shared/errors/error-handler.js';
import { notFoundHandler } from './shared/errors/not-found-handler.js';
import { createHealthRouter } from './shared/http/health.router.js';

export const buildApp = () => {
  databaseProvider.initialize();

  const app = express();
  const publicDirectory = path.resolve(process.cwd(), 'public');

  app.disable('x-powered-by');
  app.use(express.json());
  app.use(httpLogger);
  app.use(express.static(publicDirectory));

  app.use('/health', createHealthRouter());

  registerContactsModule(app);
  registerGmailModule(app);
  registerCalendarModule(app);
  registerTranslationModule(app);
  registerAiRoutingModule(app);
  registerVoiceModule(app);
  registerRemindersModule(app);
  registerCrmModule(app);
  registerJobsModule(app);
  registerDebugRoutes(app);

  app.get('/', (_request, response) => {
    response.sendFile(path.join(publicDirectory, 'index.html'));
  });


  return app;
};
