# Jarvis Backlog

## NOW
- Calendar voice output pehmendamine

## NEXT

## LATER

## DONE
- Agent control layer
