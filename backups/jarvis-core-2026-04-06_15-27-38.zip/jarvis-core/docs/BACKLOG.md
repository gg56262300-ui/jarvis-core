# Jarvis Backlog

## NOW

## NEXT
- Sentry basic
- WhatsApp Business lead-first flow

## LATER

## DONE
- Agent control layer
- Calendar voice output pehmendamine
- Gmail voice action flow
