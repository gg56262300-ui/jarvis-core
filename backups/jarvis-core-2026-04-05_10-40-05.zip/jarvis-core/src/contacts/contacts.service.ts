export class ContactsService {
  list() {
    return [];
  }
}

