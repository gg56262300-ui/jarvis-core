import type { Express } from 'express';

import { createModuleRouter } from '../shared/http/create-module-router.js';

export const registerContactsModule = (app: Express) => {
  app.use('/api/contacts', createModuleRouter('contacts'));
};

