# Repository Guidelines

## Purpose
Jarvis Core is a beginner-friendly personal AI assistant backend built with TypeScript and Express. The goal is to grow this repository into a reusable core that can later connect to n8n, messaging channels, scheduling systems, and automotive assistants without rewriting the backend from scratch.

## Project Structure
Main code lives in `src/`. The server starts from `src/index.ts` and app setup is in `src/app.ts`. The real working modules today are `src/voice` and `src/reminders`. Treat `src/translation`, `src/ai-routing`, `src/gmail`, `src/calendar`, `src/contacts`, `src/crm`, and `src/jobs` as incomplete status shells unless you verify otherwise first.

Shared code belongs in `src/shared`, config is in `src/config`, prompt text belongs in `src/*/prompts/`, static files are in `public/`, compiled output is in `dist/`, and `data/` contains runtime SQLite files and must not be treated as source code.

## Verified Working State
Preserve working functionality first. Avoid unnecessary rewrites.

- `npm run dev` works.
- `GET /health` works.
- `POST /api/voice/turns` works through OpenAI.
- `GET /api/reminders` works.
- Jarvis can create reminders with `lisa meeldetuletus ...`.
- Jarvis can list reminders with `näita meeldetuletusi`.

If a change touches voice or reminders, explain the risk clearly and verify behavior step by step.

## Beginner Workflow
Assume the user is beginner-level. Any future code change must be explained and executed step by step with no skipped assumptions. When giving terminal instructions, always say whether to use the same terminal or a new terminal. Prefer a new terminal for each new user step unless there is a strong reason to reuse the current one.

For local setup, in a new terminal run `cp .env.example .env`, then edit `.env` and keep secrets only there.

## Commands
- In a new terminal: `npm install`
- In a new terminal: `npm run dev`
- In a new terminal: `curl http://localhost:3000/health`
- After every code change, in a new terminal: `npm run build`

Use exact repo paths when explaining work, for example `src/voice/voice.service.ts` or `src/reminders/reminders.service.ts`.

## Coding Notes
Keep prompt text in `prompts/` files, not mixed into service logic. Prefer small, focused changes over broad rewrites. Preserve existing working behavior before extending the system.

## Commit and PR Notes
Do not invent commit conventions if Git history is unavailable in the workspace. If `.git` metadata is missing, say that directly instead of guessing.
