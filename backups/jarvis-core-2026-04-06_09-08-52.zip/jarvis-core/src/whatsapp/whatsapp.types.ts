export type WhatsappInboundMessage = {
  phone: string;
  name: string | null;
  message: string | null;
  channel: 'whatsapp';
};
