import { Router, type Express } from 'express';
import { WhatsappService } from './whatsapp.service.js';

const whatsappService = new WhatsappService();

export const registerWhatsappModule = (app: Express) => {
  const router = Router();

  router.post('/inbound', (req, res) => {
    const phone = String(req.body?.phone ?? '').trim();
    const name = req.body?.name ? String(req.body.name).trim() : null;
    const message = req.body?.message ? String(req.body.message).trim() : null;

    const result = whatsappService.handleInboundMessage({
      phone,
      name,
      message,
      channel: 'whatsapp',
    });

    if (result.status === 'error') {
      res.status(400).json({
        error: {
          code: 'WHATSAPP_PHONE_REQUIRED',
          message: result.responseText,
          details: null,
        },
      });
      return;
    }

    res.json(result);
  });

  app.use('/api/whatsapp', router);
};
