# AGENTS.md

## Jarvis repository working agreement

Project type:
- modular Node.js + TypeScript backend
- domain-oriented structure
- preserve existing module boundaries

Main domains:
- src/voice
- src/contacts
- src/calendar
- src/gmail
- src/reminders
- src/shared

## Repository rules

1. Follow this workflow on every non-trivial task
- inspect
- short plan
- smallest correct patch
- verification
- self-review
- explicit report

2. Protect architecture
- keep endpoint shapes stable unless explicitly asked to change them
- keep shared logic in shared areas when appropriate
- prefer root-cause fixes over surface patches
- align with existing patterns in calendar, gmail, reminders, voice, and shared

3. Verification is mandatory
Whenever relevant, run:
- npm run build
- npm run typecheck

If lint or tests do not exist, state that explicitly.
If API behavior changes, run at least one realistic curl verification.

4. Reporting format
Always end with:
1. Summary
2. Files changed
3. Commands run
4. Results
5. Risks / not verified
6. Suggested next step

5. Editing rules
- do not make unrelated edits
- do not refactor broadly unless asked
- do not silence errors to make builds pass
- do not claim “done” before verification

6. Jarvis-specific priority
Preferred delivery order for work:
- reliable local development workflow
- verified integrations
- then convenience features
- then wider automation

7. Repeated mistake prevention
If the same kind of mistake happens again:
- explain the repeated failure pattern
- change the process, not only the code
- propose an AGENTS/config update if useful
