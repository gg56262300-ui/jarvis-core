import { env } from '../config/index.js';
import { getDefaultQueue, getRedisConnection } from './queue.provider.js';

export class JobsService {
  list() {
    const redisConnection = getRedisConnection();
    const defaultQueue = getDefaultQueue();

    return [
      {
        name: 'jarvis-default',
        redisConfigured: Boolean(env.REDIS_URL),
        queuePrefix: env.REDIS_QUEUE_PREFIX,
        redisConnectionInitialized: Boolean(redisConnection),
        queueInitialized: Boolean(defaultQueue),
      },
    ];
  }
}
