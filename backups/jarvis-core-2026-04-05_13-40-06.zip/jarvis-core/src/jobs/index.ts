import { Router, type Express } from 'express';

import { JobsService } from './jobs.service.js';

const jobsService = new JobsService();

export const registerJobsModule = (app: Express) => {
  const router = Router();

  router.get('/status', (_request, response) => {
    response.json({
      status: 'ready',
      jobs: jobsService.list(),
    });
  });

  app.use('/api/jobs', router);
};
