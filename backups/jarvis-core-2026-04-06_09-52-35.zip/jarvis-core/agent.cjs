const { execSync } = require("child_process");

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

async function askAI(prompt) {
  const res = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-5.4",
      input: prompt
    })
  });

  const data = await res.json();
  return data.output[0].content[0].text;
}

function runCommand(cmd) {
  try {
    return execSync(cmd, { encoding: "utf-8" });
  } catch (err) {
    return (err.stdout || "") + (err.stderr || "");
  }
}

async function main() {
  const goal = process.argv.slice(2).join(" ");
  if (!goal) {
    console.log("❌ Give goal: node agent.js \"task\"");
    return;
  }

  let context = `GOAL: ${goal}\n`;

  for (let i = 0; i < 10; i++) {
    console.log(`\n🔁 STEP ${i+1}`);

    const prompt = context + `
You are a terminal agent.
Return ONLY a bash command.
No explanations.
`;

    const command = await askAI(prompt);
    console.log("🤖", command);

    if (command.toLowerCase().includes("done")) break;

    const output = runCommand(command);
    console.log("📤", output);

    context += `
CMD: ${command}
OUT:
${output}
`;
  }
}

main();
