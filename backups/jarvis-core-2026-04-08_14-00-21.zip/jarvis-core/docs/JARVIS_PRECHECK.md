# JARVIS PRECHECK

## Enne igat muudatust kontrolli 4 asja

1. Mida see muudab?
2. Mida see võib lõhkuda?
3. Kuidas ma tõestan, et see ei lõhkunud?
4. Kas pärast seda on vaja checkpoint-backup?

## Vastuse vorm

- MUUDATUS:
- RISK:
- TÕESTUS:
- BACKUP: yes/no
- OTSUS: proceed / stop

## Reegel

Kui risk või mõju ei ole selge, siis otsus = STOP.
Kui test puudub, siis otsus = STOP.
Kui muutus puudutab state, rollback, execution või terminal capture loogikat, siis backup = YES.

## Lisareeglid pärast tänast postmortemit

5. Kontrolli kogu ahelat, mitte ainult üht punkti:
   - kirjutus
   - lugemine
   - kuvamine
   - tõestustest

6. Kui väljund peab minema faili + clipboardi + terminali, siis järjekord on:
   - fail
   - clipboard
   - terminal

7. Kui muutus puudutab output-path, pipe, tee või pbcopy loogikat, siis tuleb teha runtime-test, mis kinnitab:
   - tekst on terminalis nähtav
   - tekst on failis olemas
   - tekst on clipboardis

8. Kui current-state kuva sõltub mitmest failist, siis tuleb enne valmis lugemist kontrollida:
   - milline fail on värskem
   - milline fail on source of truth
   - mida route eelistab vastuolu korral
