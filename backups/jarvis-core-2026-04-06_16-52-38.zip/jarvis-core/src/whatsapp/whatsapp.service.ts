import { CrmService } from '../crm/crm.service.js';
import type { WhatsappInboundMessage } from './whatsapp.types.js';

export class WhatsappService {
  private readonly crmService = new CrmService();

  handleInboundMessage(input: WhatsappInboundMessage) {
    const normalizedPhone = input.phone.replace(/[^\d+]/g, '').trim();

    if (!normalizedPhone) {
      return {
        status: 'error' as const,
        responseText: 'WhatsApp inbound sõnumis puudub telefoninumber.',
      };
    }

    const leadResult = this.crmService.upsertLead({
      source: 'whatsapp',
      phone: normalizedPhone,
      name: input.name,
      tag: 'whatsapp-inbound',
      notes: input.message ?? null,
      projectCode: input.projectCode ?? null,
      city: input.city ?? null,
      serviceType: input.serviceType ?? null,
    });

    const lead = leadResult.lead;

    const messageRecord =
      input.message && input.message.trim()
        ? this.crmService.addLeadMessage({
            leadId: lead.id,
            channel: 'whatsapp',
            direction: 'inbound',
            message: input.message.trim(),
          })
        : null;

    const missingFields = [
      !lead.name ? 'name' : null,
      !lead.projectCode ? 'projectCode' : null,
      !lead.city ? 'city' : null,
      !lead.serviceType ? 'serviceType' : null,
    ].filter(Boolean) as string[];

    const nextAction =
      missingFields.length === 0
        ? 'ready'
        : missingFields[0] === 'name'
          ? 'ask_name'
          : missingFields[0] === 'projectCode'
            ? 'ask_project_code'
            : missingFields[0] === 'city'
              ? 'ask_city'
              : 'ask_service_type';

    return {
      status: 'ready' as const,
      responseText: leadResult.isNewLead
        ? `WhatsApp uus lead salvestatud: ${lead.phone}.`
        : `WhatsApp olemasolev lead uuendatud: ${lead.phone}.`,
      leadStatus: leadResult.isNewLead ? 'new' as const : 'updated' as const,
      isNewLead: leadResult.isNewLead,
      nextAction,
      missingFields,
      lead,
      messageRecord,
    };
  }
}
